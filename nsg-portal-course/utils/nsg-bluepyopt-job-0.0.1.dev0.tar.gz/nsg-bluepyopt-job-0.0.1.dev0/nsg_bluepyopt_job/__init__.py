""" nsg_bluepyopt_job """

from nsg_bluepyopt_job.version import __version__
