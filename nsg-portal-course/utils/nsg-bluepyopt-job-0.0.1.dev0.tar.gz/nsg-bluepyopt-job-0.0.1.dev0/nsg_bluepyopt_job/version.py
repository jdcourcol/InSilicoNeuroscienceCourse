""" Package version. """

VERSION = "0.0.1.dev0"
__version__ = VERSION
