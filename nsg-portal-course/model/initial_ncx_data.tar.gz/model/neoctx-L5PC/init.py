import os
os.system('python opt_neuron.py --max_ngen=20 --offspring_size=20 --start --checkpoint ./checkpoints/checkpoint.pkl')
