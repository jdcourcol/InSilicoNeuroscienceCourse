import os
os.system('python opt_neuron.py --max_ngen=2 --offspring_size=10 --start --checkpoint ./checkpoints/checkpoint.pkl')
